# config.py — Spaghetti-Waechter: alle Einstellungen an einem Ort.
# Werte mit ⚠️ VOR dem ersten Lauf anpassen.

# ── Kamera ────────────────────────────────────────────────────
CAMERA_SOURCE = "csi:0"        # Pi Camera 2 am UNO Media Carrier (CSI0)
                               # Alternativen: "usb:0", "/dev/video0"
CAMERA_RESOLUTION = (640, 480)  # libcamera liefert real 632 × 480

# ── Pruefzyklus / Zeitfilter ──────────────────────────────────
CHECK_INTERVAL_S = 15          # Sekunden zwischen zwei Pruefungen
ALARM_WINDOW = 4               # ... der letzten N Pruefungen ...
ALARM_HITS = 3                 # ... muessen anomal sein → Alarm (3 von 4)
SCORE_THRESHOLD = 100.0        # ⚠️ MUSS fuer eure Szene bestimmt werden!
                               # 100 = Beobachtermodus: nie Alarm, aber
                               # Scores werden angezeigt und Bilder
                               # gesammelt. Vorgehen siehe Teil 5: Normal-
                               # und Fehlerbilder im Model testing
                               # gegeneinanderlegen, Schwelle in die
                               # Luecke setzen. Ein aus einem fremden
                               # Aufbau uebernommener Wert ist wertlos.

# ── Moonraker (Elegoo Neptune 4 Plus, Port 80 ab Werk) ────────
MOONRAKER_HOST = "192.168.1.50"  # ⚠️ IP eures Druckers (Klipper/Moonraker)
ONLY_WHILE_PRINTING = True      # Nur alarmieren, wenn wirklich gedruckt wird
AUTO_PAUSE = False              # Opt-in! Erst nach validierter Schwelle True.
PRINT_WARMUP_S = 0              # Homing/Purge nicht fuer den Alarm werten —
                                # Szene fehlt im Training (0 = aus); Score
                                # wird trotzdem angezeigt. 60 s gibt die
                                # kritische erste Schicht frei (28.08.).

# ── Home Assistant / MQTT (Mosquitto laeuft, Discovery-Weg) ───
MQTT_HOST = "192.168.1.10"      # ⚠️ IP eures MQTT-Brokers / Home Assistant
MQTT_PORT = 1883
MQTT_USER = "DEIN_MQTT_BENUTZER"      # ⚠️ anpassen
MQTT_PASSWORD = "DEIN_MQTT_PASSWORT"  # ⚠️ anpassen
DISCOVERY_PREFIX = "homeassistant"
DEVICE_ID = "unoq_spaghetti"
DEVICE_NAME = "Spaghetti-Waechter (UNO Q)"

# ── Diagnose & Datensammlung ──────────────────────────────────
# /app = App-Ordner auf dem Board (~/ArduinoApps/spaghetti-waechter) —
# der einzige Pfad, der App-Neustarts uebersteht (Container ist Wegwerfware).
SAVE_ALARM_FRAMES = True        # Alarm-Frames als Beleg sichern
ALARM_FRAME_DIR = "/app/data/alarme"
DEBUG_SAVE_LAST = True          # jedes Modell-Bild nach /tmp/spaghetti_debug.jpg
                                # (im Container!) — fuer Threshold-Diagnose

COLLECT_TRAINING_FRAMES = True  # Rotierender Trainings-Puffer: jedes Bild
TRAINING_FRAME_DIR = "/app/data/training"   # unterhalb der Schwelle wird
TRAINING_FRAME_MAX = 2500       # gesichert, die aeltesten fliegen raus.
                                # Bei Bedarf (Re-Training) einfach abziehen.
